package com.chatroom.restchat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
