package com.chatroom.restchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestChatApplication.class, args);
	}

}
